package com.cineverse.exception;

public class SeatOccupiedException extends BusinessException {
    public SeatOccupiedException(String seatNo) {
        super("Koltuk " + seatNo + " zaten dolu! Lütfen başka koltuk seçiniz.");
    }
}