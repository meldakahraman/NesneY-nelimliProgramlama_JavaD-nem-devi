package com.cineverse.gui;

import java.net.URL;
import java.net.URLEncoder;
import javax.imageio.ImageIO;
import java.nio.charset.StandardCharsets;

import com.cineverse.model.*;
import com.cineverse.service.CinemaService;
import com.cineverse.service.EmailService;
import com.cineverse.util.FileHelper;
import com.cineverse.util.ThemeColors;
import com.cineverse.exception.SeatOccupiedException;
import com.cineverse.exception.BusinessException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainFrame extends JFrame {
    //askıda bilet havuzu
    private static int suspendedTicketsPool = 5;

    private CinemaService<Movie> movieService;
    private JPanel mainPanel;
    private CardLayout cardLayout; // Sayfalar arası geçişi sağlayan yönetici

    // Kullanıcı veritabanı RAM'de tutulur, dosydan yüklenir
    private Map<String, Customer> registeredUsers = new HashMap<>();
    private Customer currentUser;

    private JTextField txtLoginUser;
    private JPasswordField txtLoginPass;

    // Seçimlerin tutulduğu değişkenler
    private Movie selectedMovie;
    private String selectedCinema;
    private Session selectedSession;

    // Fiyat ve adet sayaçları
    private int countTam = 0, countOgrenci = 0, countAskida = 0, countBagis = 0;
    private int totalSeatsNeeded = 0;
    private double currentTotalPrice = 0.0;
    private List<Seat> selectedSeatsList = new ArrayList<>();

    // AVM / Sinema Listesi
    private final String[] ALL_CINEMAS = {
            "MEGEVERSE ANKAmall", "MEGEVERSE Atakule", "MEGEVERSE Armada", "MEGEVERSE Antares AVM",
            "MEGEVERSE Cepa", "MEGEVERSE Podium Ankara", "MEGEVERSE Panora", "MEGEVERSE Atlantis Batıkent",
            "MEGEVERSE Metromall", "MEGEVERSE Podium Kırıkkale", "MEGEVERSE 14 Bolu Burda", "MEGEVERSE Çorum",
            "MEGEVERSE Espark", "MEGEVERSE Kent Plaza", "MEGEVERSE Serdivan", "MEGEVERSE Park Afyon",
            "MEGEVERSE Forum Kayseri", "MEGEVERSE 41 Izmit Burda", "MEGEVERSE Kayseri Park", "MEGEVERSE Gebze Center",
            "MEGEVERSE Viaport", "MEGEVERSE Pendorya", "MEGEVERSE Yeşilyurt", "MEGEVERSE Piazza Samsun",
            "MEGEVERSE Bursa Marka", "MEGEVERSE Anatolium Marmara", "MEGEVERSE Maltepe Piazza", "MEGEVERSE Bursa Podyumpark",
            "MEGEVERSE Metrogarden", "MEGEVERSE Hilltown Küçükyalı", "MEGEVERSE Akyaka Park", "MEGEVERSE Acarkent Coliseum",
            "MEGEVERSE Emaar Square Mall", "MEGEVERSE Akasya", "MEGEVERSE Tepe Nautilus", "MEGEVERSE Zorlu Center",
            "MEGEVERSE İstinyePark (İstanbul)", "MEGEVERSE Kanyon", "MEGEVERSE Trump", "MEGEVERSE Cevahir",
            "MEGEVERSE Axis Kağıthane AVM", "MEGEVERSE Historia", "MEGEVERSE Vadistanbul", "MEGEVERSE Eyüp - Axis İstanbul AVM",
            "MEGEVERSE Vialand AVM", "MEGEVERSE Capacity", "MEGEVERSE Kale", "MEGEVERSE A Plus",
            "MEGEVERSE Aqua Florya", "MEGEVERSE Manavgat", "MEGEVERSE Marmara Park", "MEGEVERSE Avlu 34 AVM",
            "MEGEVERSE Akbatı", "MEGEVERSE Tarsu", "MEGEVERSE Forum Mersin", "MEGEVERSE M1 Adana AVM",
            "MEGEVERSE MarkAntalya", "MEGEVERSE Antalya Migros", "MEGEVERSE Denizli SM", "MEGEVERSE Osmaniye",
            "MEGEVERSE Piazza Kahramanmaraş", "MEGEVERSE Tekira", "MEGEVERSE Forum Gaziantep", "MEGEVERSE Forum Bornova",
            "MEGEVERSE Point Bornova", "MEGEVERSE Konak Pier", "MEGEVERSE İzmir Park", "MEGEVERSE Karşıyaka Hilltown",
            "MEGEVERSE MaviBahçe", "MEGEVERSE Optimum İzmir", "MEGEVERSE 17 Çanakkale Burda", "MEGEVERSE Bodrum Midtown Alışveriş Merkezi",
            "MEGEVERSE Forum Trabzon", "MEGEVERSE Şanlıurfa Piazza", "MEGEVERSE Diyarbakir Ceylan Karavil Park", "MEGEVERSE Erzurum MNG",
            "MEGEVERSE Van"
    };

    public MainFrame() {
        movieService = new CinemaService<>();
        initData();
        registeredUsers = FileHelper.loadUsersFromFile(); // Dosyadan kullanıcıları çeker

        setTitle("MEGEVERSE - Sinema Dünyası");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Tam ekran aç
        setSize(1200, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        // Ana Panel ve Layout Kurulumu
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        // Panelleri sisteme ekle
        mainPanel.add(createAuthPanel(), "AUTH");
        mainPanel.add(createHomePanel(), "HOME");

        add(mainPanel);
        cardLayout.show(mainPanel, "AUTH");// İlk açılışta Giriş ekranını göster

        FileHelper.logIslem("Uygulama başlatıldı: " + LocalDateTime.now());
    }
    // Örnek film verilerini belleğe yükler
    private void initData() {
        movieService.add(new Movie(1, "OPPENHEIMER", 200.0, "Biyografi/Dram", 180));
        movieService.add(new Movie(2, "BARBIE", 180.0, "Komedi/Macera", 114));
        movieService.add(new Movie(3, "AVENGERS: ENDGAME", 250.0, "Aksiyon/Fantastik", 181));
        movieService.add(new Movie(4, "SPIDER-MAN: NO WAY HOME", 240.0, "Macera/Aksiyon", 148));
        movieService.add(new Movie(5, "IRON MAN", 220.0, "Bilim Kurgu", 126));
        movieService.add(new Movie(6, "MISSION IMPOSSIBLE 7", 200.0, "Aksiyon", 163));
        movieService.add(new Movie(7, "JOKER: IKILI DELILIK", 210.0, "Suç/Dram", 138));
        movieService.add(new Movie(8, "DEADPOOL & WOLVERINE", 230.0, "Komedi/Aksiyon", 127));
    }

    private JPanel createAuthPanel() {
        JPanel mainContainer = new JPanel(new GridBagLayout());
        mainContainer.setBackground(ThemeColors.BACKGROUND_LIGHT);

        JPanel cardContainer = new JPanel(new CardLayout());
        cardContainer.setPreferredSize(new Dimension(500, 750)); // Yüksekliği biraz artırdım

        //  LOGIN FORMU
        JPanel loginPanel = new JPanel(new GridLayout(8, 1, 15, 15));
        loginPanel.setBackground(Color.WHITE);
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 2),
                new EmptyBorder(40, 40, 40, 40)));

        // GİRİŞ YAP BAŞLIĞI
        JLabel lblLogin = new JLabel("GİRİŞ YAP", SwingConstants.CENTER);
        lblLogin.setFont(new Font("SansSerif", Font.BOLD, 32));
        lblLogin.setForeground(ThemeColors.TEXT_DARK);

        // MEGEVERSE ALT BAŞLIĞI
        JLabel lblSub = new JLabel("MEGEVERSE", SwingConstants.CENTER);
        lblSub.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblSub.setForeground(ThemeColors.PRIMARY_ORANGE);
        lblSub.setBorder(new EmptyBorder(0, 0, 20, 0));

        JPanel pnlUser = new JPanel(new BorderLayout());
        pnlUser.setBackground(Color.WHITE);
        pnlUser.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY), "Kullanıcı Adı"));
        txtLoginUser = new JTextField();
        txtLoginUser.setFont(new Font("SansSerif", Font.PLAIN, 16));
        txtLoginUser.setBorder(new EmptyBorder(5, 5, 5, 5));
        pnlUser.add(txtLoginUser);

        // ŞİFRE PANELİ
        txtLoginPass = new JPasswordField();
        JPanel pnlPass = createPasswordPanelWithToggle(txtLoginPass, "Şifre");

        JButton btnLogin = new JButton("GİRİŞ");
        styleOrangeButton(btnLogin);
        btnLogin.setFont(new Font("SansSerif", Font.BOLD, 18));

        // ŞİFREMİ UNUTTUM
        JButton btnForgot = new JButton("Şifremi Unuttum");
        btnForgot.setBorderPainted(false);
        btnForgot.setContentAreaFilled(false);
        btnForgot.setForeground(Color.RED);
        btnForgot.setFont(new Font("SansSerif", Font.PLAIN, 12));
        btnForgot.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JButton btnGoToRegister = new JButton("<html><u>Hesabın yok mu? Kayıt Ol</u></html>");
        btnGoToRegister.setBorderPainted(false);
        btnGoToRegister.setContentAreaFilled(false);
        btnGoToRegister.setForeground(Color.BLUE);
        btnGoToRegister.setFont(new Font("SansSerif", Font.PLAIN, 14));
        btnGoToRegister.setCursor(new Cursor(Cursor.HAND_CURSOR));

        loginPanel.add(lblLogin);
        loginPanel.add(lblSub); // MEGEVERSE eklendi
        loginPanel.add(pnlUser);
        loginPanel.add(pnlPass);
        loginPanel.add(btnLogin);
        loginPanel.add(btnForgot); // Şifremi unuttum eklendi
        loginPanel.add(btnGoToRegister);

        //  REGISTER FORMU
        JPanel registerPanel = new JPanel(new GridLayout(8, 1, 10, 10));
        registerPanel.setBackground(Color.WHITE);
        registerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 2),
                new EmptyBorder(30, 40, 30, 40)));

        JLabel lblReg = new JLabel("KAYIT OL", SwingConstants.CENTER);
        lblReg.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblReg.setForeground(ThemeColors.PRIMARY_ORANGE);

        JTextField txtRegName = createStyledTextField("Ad Soyad");
        JTextField txtRegUser = createStyledTextField("Kullanıcı Adı (Giriş İçin)");
        JTextField txtRegEmail = createStyledTextField("Gmail Adresi");

        // şifreler sansürlenecek göze tıklayınca gözükecek
        JPasswordField txtRegPass = new JPasswordField();
        JPanel pnlRegPass = createPasswordPanelWithToggle(txtRegPass, "Şifre (Giriş İçin)");

        JPasswordField txtRegAppPass = new JPasswordField();
        JPanel pnlRegAppPass = createPasswordPanelWithToggle(txtRegAppPass, "Gmail Uygulama Şifresi (16 Hane)");

        JButton btnRegister = new JButton("KAYDI TAMAMLA");
        styleOrangeButton(btnRegister);
        btnRegister.setFont(new Font("SansSerif", Font.BOLD, 16));

        JButton btnGoToLogin = new JButton("<html><u>Zaten hesabın var mı? Giriş Yap</u></html>");
        btnGoToLogin.setBorderPainted(false);
        btnGoToLogin.setContentAreaFilled(false);
        btnGoToLogin.setForeground(Color.BLUE);
        btnGoToLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));

        registerPanel.add(lblReg);
        registerPanel.add(txtRegName);
        registerPanel.add(txtRegUser);
        registerPanel.add(txtRegEmail);
        registerPanel.add(pnlRegPass);
        registerPanel.add(pnlRegAppPass);
        registerPanel.add(btnRegister);
        registerPanel.add(btnGoToLogin);

        cardContainer.add(loginPanel, "LOGIN");
        cardContainer.add(registerPanel, "REGISTER");

        mainContainer.add(cardContainer);

        //  BUTON AKSİYONLARI
        CardLayout clAuth = (CardLayout) cardContainer.getLayout();

        btnGoToRegister.addActionListener(e -> clAuth.show(cardContainer, "REGISTER"));
        btnGoToLogin.addActionListener(e -> clAuth.show(cardContainer, "LOGIN"));

        // ŞİFREMİ UNUTTUM
        btnForgot.addActionListener(e -> {
            String inputEmail = JOptionPane.showInputDialog(mainContainer, "Kayıtlı E-Posta adresinizi giriniz:");
            if (inputEmail != null && !inputEmail.isEmpty()) {
                boolean found = false;
                for (Customer c : registeredUsers.values()) {
                    if (c.getEmail().equalsIgnoreCase(inputEmail)) {
                        found = true;
                        // Mail gönderme işlemi (Kullanıcının kendi app şifresiyle kendine mail atması)
                        new Thread(() -> {
                            try {
                                EmailService.sendRecoveryEmail(
                                        c.getEmail(), c.getAppPassword(), c.getEmail(), c.getPassword()
                                );
                                SwingUtilities.invokeLater(() ->
                                        JOptionPane.showMessageDialog(mainContainer, "Şifreniz mail adresinize gönderildi! Lütfen kontrol ediniz.")
                                );
                            } catch (Exception ex) {
                                SwingUtilities.invokeLater(() ->
                                        JOptionPane.showMessageDialog(mainContainer, "Mail gönderilemedi! (App Password hatası olabilir)")
                                );
                            }
                        }).start();
                        break;
                    }
                }
                if (!found) {
                    JOptionPane.showMessageDialog(mainContainer, "Bu mail adresiyle kayıtlı kullanıcı bulunamadı.", "Hata", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // KAYIT
        btnRegister.addActionListener(e -> {
            String name = txtRegName.getText();
            String user = txtRegUser.getText();
            String normalPass = new String(txtRegPass.getPassword());
            String mail = txtRegEmail.getText();
            String appPass = new String(txtRegAppPass.getPassword());

            if(name.isEmpty() || user.isEmpty() || normalPass.isEmpty() || mail.isEmpty() || appPass.isEmpty()) {
                JOptionPane.showMessageDialog(mainContainer, "Lütfen tüm alanları doldurun!");
                return;
            }
            if(registeredUsers.containsKey(user)) {
                JOptionPane.showMessageDialog(mainContainer, "Bu kullanıcı adı zaten alınmış!");
                return;
            }

            Customer newCustomer = new Customer(name, user, normalPass, appPass, mail, (byte)20, true);
            registeredUsers.put(user, newCustomer);
            FileHelper.saveUserToFile(newCustomer);

            JOptionPane.showMessageDialog(mainContainer, "Kayıt Başarılı!\nŞimdi belirlediğiniz şifre ile giriş yapabilirsiniz.");
            clAuth.show(cardContainer, "LOGIN");
        });

        // GİRİŞ İŞLEMİ
        btnLogin.addActionListener(e -> {
            String u = txtLoginUser.getText();
            String p = new String(txtLoginPass.getPassword());

            if(registeredUsers.containsKey(u)) {
                Customer c = registeredUsers.get(u);
                if(c.getPassword().equals(p)) {
                    currentUser = c;

                    // Eski biletleri yükle
                    currentUser.getTicketHistory().clear();
                    currentUser.getTicketHistory().addAll(FileHelper.loadTicketsForUser(c.getUsername()));

                    // bilgileri her giriş yap butonuna tıklayınca siler
                    txtLoginUser.setText(""); // Kullanıcı adını sil
                    txtLoginPass.setText(""); // Şifreyi sil
                    // ---------------------------------------------

                    JOptionPane.showMessageDialog(mainContainer, "Hoşgeldin, " + c.getName());
                    cardLayout.show(mainPanel, "HOME");
                } else {
                    JOptionPane.showMessageDialog(mainContainer, "Hatalı şifre!", "Hata", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(mainContainer, "Kullanıcı bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        return mainContainer;
    }

    // şifre paneli için şifrenin görünür yapılması
    private JPanel createPasswordPanelWithToggle(JPasswordField passField, String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY), title));

        passField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        passField.setBorder(new EmptyBorder(5, 5, 5, 5));

        // Göz İkonu
        JToggleButton btnShow = new JToggleButton("👁"); // Unicode Göz İkonu
        btnShow.setFocusPainted(false);
        btnShow.setBorderPainted(false);
        btnShow.setContentAreaFilled(false);
        btnShow.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnShow.addActionListener(e -> {
            if (btnShow.isSelected()) {
                passField.setEchoChar((char) 0); // Şifreyi göster
            } else {
                passField.setEchoChar('•'); // Şifreyi gizle
            }
        });

        panel.add(passField, BorderLayout.CENTER);
        panel.add(btnShow, BorderLayout.EAST);
        return panel;
    }

    private JTextField createStyledTextField(String title) {
        JTextField tf = new JTextField();
        tf.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY), title));
        return tf;
    }

    // ANASAYFA filmlerin listelendiği ekran
    private JPanel createHomePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ThemeColors.BACKGROUND_LIGHT);

        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 30, 20));
        header.setBackground(Color.WHITE);

        JLabel logo = new JLabel("MEGEVERSE");
        logo.setFont(new Font("SansSerif", Font.BOLD, 28));
        logo.setForeground(ThemeColors.PRIMARY_ORANGE);
        header.add(logo);

        JButton btnSmartSuggest = new JButton("🤖 Ne İzlesem?");
        styleOrangeButton(btnSmartSuggest);
        btnSmartSuggest.setBackground(new Color(66, 165, 245));
        btnSmartSuggest.addActionListener(e -> startSmartSuggestionLoop());
        header.add(Box.createHorizontalStrut(20));
        header.add(btnSmartSuggest);

        JButton btnMyTickets = new JButton("🎟️ Biletlerim");
        styleOrangeButton(btnMyTickets);
        btnMyTickets.setBackground(Color.GRAY);
        btnMyTickets.addActionListener(e -> showMyTickets());
        header.add(btnMyTickets);

        JButton btnLogout = new JButton("Çıkış");
        btnLogout.addActionListener(e -> {
            currentUser = null;
            cardLayout.show(mainPanel, "AUTH");
        });
        header.add(btnLogout);

        JPanel moviesGrid = new JPanel(new GridLayout(0, 4, 20, 20));
        moviesGrid.setBackground(ThemeColors.BACKGROUND_LIGHT);
        moviesGrid.setBorder(new EmptyBorder(20, 40, 20, 40));

        for (Movie m : movieService.getAll()) {// filmleri döngü ile ekrana basar
            moviesGrid.add(createMovieCard(m));
        }

        JScrollPane scrollPane = new JScrollPane(moviesGrid);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        panel.add(header, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    // Biletlerim ekranı QRlı
    private void showMyTickets() {
        JDialog dialog = new JDialog(this, "Bilet Koleksiyonum", true);
        dialog.setSize(550, 700);
        dialog.setLayout(new BorderLayout());
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(ThemeColors.BACKGROUND_LIGHT);

        // Ana Liste Paneli (Biletler buraya alt alta dizilecek)
        JPanel mainListPanel = new JPanel();
        mainListPanel.setLayout(new BoxLayout(mainListPanel, BoxLayout.Y_AXIS));
        mainListPanel.setBackground(ThemeColors.BACKGROUND_LIGHT);
        mainListPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        List<String> history = currentUser.getTicketHistory();

        if (history.isEmpty()) {
            JLabel lblEmpty = new JLabel("Henüz biletiniz yok. Hemen bir film seçin!", SwingConstants.CENTER);
            lblEmpty.setFont(new Font("SansSerif", Font.BOLD, 16));
            lblEmpty.setForeground(Color.GRAY);
            lblEmpty.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Dikey ortalamak için boşluklar
            mainListPanel.add(Box.createVerticalGlue());
            mainListPanel.add(lblEmpty);
            mainListPanel.add(Box.createVerticalGlue());
        } else {
            // Ters döngü kuruyoruz ki EN SON alınan bilet EN ÜSTTE gözüksün
            for (int i = history.size() - 1; i >= 0; i--) {
                String ticketData = history.get(i);
                mainListPanel.add(createTicketCard(ticketData));
                mainListPanel.add(Box.createVerticalStrut(15)); // Kartlar arası boşluk
            }
        }

        JScrollPane scrollPane = new JScrollPane(mainListPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16); // Kaydırma hızı

        dialog.add(scrollPane, BorderLayout.CENTER);

        // Alt Kısım (Kapat Butonu)
        JButton btnClose = new JButton("Kapat");
        styleOrangeButton(btnClose);
        btnClose.addActionListener(e -> dialog.dispose());

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        bottomPanel.add(btnClose);

        dialog.add(bottomPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // biletleri oluşturur
    private JPanel createTicketCard(String ticketData) {
        // Veri Formatımız: Film Adı | Sinema - Tarih | Koltuklar: A1 A2
        String[] parts = ticketData.split("\\|");

        String movieName = parts.length > 0 ? parts[0].trim() : "Bilinmiyor";
        String locationDate = parts.length > 1 ? parts[1].trim() : "Tarih Yok";
        String seats = parts.length > 2 ? parts[2].trim() : "Koltuk Yok";

        // Kartın Ana Paneli
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
                BorderFactory.createMatteBorder(0, 6, 0, 0, ThemeColors.PRIMARY_ORANGE)
        ));
        card.setMaximumSize(new Dimension(500, 140));
        card.setPreferredSize(new Dimension(480, 140));

        // sol taraf Film ve Detaylar
        JPanel infoPanel = new JPanel(new GridLayout(3, 1, 5, 0));
        infoPanel.setBackground(Color.WHITE);
        infoPanel.setBorder(new EmptyBorder(10, 15, 10, 10));

        JLabel lblMovie = new JLabel(movieName);
        lblMovie.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblMovie.setForeground(ThemeColors.TEXT_DARK);

        JLabel lblLocDate = new JLabel("<html>" + locationDate.replace(" - ", "<br>") + "</html>");
        lblLocDate.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblLocDate.setForeground(Color.GRAY);

        JLabel lblSeats = new JLabel(seats);
        lblSeats.setFont(new Font("Monospaced", Font.BOLD, 14));
        lblSeats.setForeground(ThemeColors.PRIMARY_ORANGE);

        infoPanel.add(lblMovie);
        infoPanel.add(lblLocDate);
        infoPanel.add(lblSeats);

        //  Sağ Taraf qr kod
        JPanel qrPanel = new JPanel(new GridBagLayout()); // Ortalamak için
        qrPanel.setBackground(new Color(250, 250, 250));
        qrPanel.setPreferredSize(new Dimension(110, 0)); // QR alanı genişliği
        qrPanel.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, Color.LIGHT_GRAY));

        JLabel lblQr = new JLabel("Yükleniyor...");
        lblQr.setHorizontalAlignment(SwingConstants.CENTER);

        /* QR KOD OLUŞTURMA (İNTERNETTEN ÇEKME)
        Bu işlem internet hızına bağlı olduğu için arayüzü dondurmasın diye
        ayrı bir Thread içinde yapıyoruz.*/
        new Thread(() -> {
            try {
                // QR Kodun içinde yazacak metni hazırlıyoruz
                String qrText = "MEGEVERSE Bilet\nFilm: " + movieName + "\n" + locationDate + "\n" + seats;

                // URL içinde Türkçe karakterler sorun olmasın diye encode ediyoruz
                String encodedText = URLEncoder.encode(qrText, StandardCharsets.UTF_8.toString());

                // Ücretsiz QR API'sine istek atıyoruz (80x80 boyutunda)
                String urlStr = "https://api.qrserver.com/v1/create-qr-code/?data=" + encodedText + "&size=90x90";
                URL url = new URL(urlStr);

                // Resmi indirip ikona çeviriyoruz
                Image image = ImageIO.read(url);
                ImageIcon icon = new ImageIcon(image);

                // Label'ı güncelliyoruz
                SwingUtilities.invokeLater(() -> {
                    lblQr.setText(""); // Yazıyı sil
                    lblQr.setIcon(icon); // Resmi koy
                });

            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> {
                    lblQr.setText("QR Hata");
                    lblQr.setFont(new Font("SansSerif", Font.PLAIN, 10));
                });
            }
        }).start();


        qrPanel.add(lblQr);

        card.add(infoPanel, BorderLayout.CENTER);
        card.add(qrPanel, BorderLayout.EAST);

        return card;
    }
    // film ve sinema seçimi
    private JPanel createMovieCard(Movie m) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(220, 220, 220), 1), new EmptyBorder(10, 10, 10, 10)));
        JLabel posterLabel = new JLabel();
        posterLabel.setHorizontalAlignment(SwingConstants.CENTER);
        posterLabel.setPreferredSize(new Dimension(180, 260));
        File imgFile = new File("images/" + m.getId() + ".jpg");
        if (imgFile.exists()) {
            ImageIcon icon = new ImageIcon(imgFile.getPath());
            Image img = icon.getImage().getScaledInstance(180, 260, Image.SCALE_SMOOTH);
            posterLabel.setIcon(new ImageIcon(img));
        } else {
            posterLabel.setText("<html><center>AFİŞ YOK<br>" + m.getName() + "</center></html>");
            posterLabel.setOpaque(true);
            posterLabel.setBackground(new Color(230, 230, 230));
        }
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBackground(Color.WHITE);
        JLabel title = new JLabel(m.getName());
        title.setFont(new Font("SansSerif", Font.BOLD, 12));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btnDetail = new JButton("SİNEMA SEÇ");
        styleOrangeButton(btnDetail);
        btnDetail.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnDetail.addActionListener(e -> {
            selectedMovie = m;
            mainPanel.add(createCinemaSelectionPanel(m), "CINEMA");
            cardLayout.show(mainPanel, "CINEMA");
        });

        infoPanel.add(title);
        infoPanel.add(Box.createVerticalStrut(10));
        infoPanel.add(btnDetail);
        card.add(posterLabel, BorderLayout.CENTER);
        card.add(infoPanel, BorderLayout.SOUTH);
        return card;
    }

    // SİNEMA (LOKASYON) SEÇİM PANELİ
    private JPanel createCinemaSelectionPanel(Movie m) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ThemeColors.BACKGROUND_LIGHT);

        JLabel header = new JLabel("SİNEMA SEÇİNİZ (" + m.getName() + ")", SwingConstants.CENTER);
        header.setFont(new Font("SansSerif", Font.BOLD, 22));
        header.setBorder(new EmptyBorder(20,0,20,0));
        header.setForeground(ThemeColors.PRIMARY_ORANGE);
        panel.add(header, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.setBackground(ThemeColors.BACKGROUND_LIGHT);
        JTextField txtSearch = new JTextField(20);
        txtSearch.setBorder(BorderFactory.createTitledBorder("Şehir/Sinema Ara"));
        searchPanel.add(txtSearch);

        DefaultListModel<String> listModel = new DefaultListModel<>();
        for(String cinema : ALL_CINEMAS) listModel.addElement(cinema);

        JList<String> list = new JList<>(listModel);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setFont(new Font("SansSerif", Font.PLAIN, 16));
        list.setFixedCellHeight(40);

        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filter(); }
            public void removeUpdate(DocumentEvent e) { filter(); }
            public void changedUpdate(DocumentEvent e) { filter(); }
            void filter() {
                String filter = txtSearch.getText().toLowerCase();
                listModel.clear();
                for (String s : ALL_CINEMAS) if (s.toLowerCase().contains(filter)) listModel.addElement(s);
            }
        });

        JScrollPane scrollPane = new JScrollPane(list);
        scrollPane.setBorder(new EmptyBorder(10, 50, 10, 50));

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        panel.add(centerPanel, BorderLayout.CENTER);

        JButton btnNext = new JButton("SEANSLARI GÖR >>");
        styleOrangeButton(btnNext);
        btnNext.addActionListener(e -> {
            String selection = list.getSelectedValue();
            if(selection == null) JOptionPane.showMessageDialog(panel, "Lütfen bir sinema seçiniz.");
            else {
                selectedCinema = selection;
                mainPanel.add(createSessionPanel(m), "SESSION");
                cardLayout.show(mainPanel, "SESSION");
            }
        });

        JButton btnBack = new JButton("<< GERİ");
        btnBack.setBackground(Color.GRAY);
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(ev -> cardLayout.show(mainPanel, "HOME"));

        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.add(btnBack);
        bottomPanel.add(btnNext);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    //  SEANS SEÇİMİ
    private JPanel createSessionPanel(Movie m) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ThemeColors.BACKGROUND_LIGHT);

        JLabel header = new JLabel("<html><center>" + m.getName() + "<br><font size='4' color='gray'>" + selectedCinema + "</font></center></html>", SwingConstants.CENTER);
        header.setFont(new Font("SansSerif", Font.BOLD, 22));
        header.setBorder(new EmptyBorder(10,0,10,0));
        header.setForeground(ThemeColors.PRIMARY_ORANGE);
        panel.add(header, BorderLayout.NORTH);

        JPanel weeklyGrid = new JPanel(new GridLayout(1, 7, 15, 0));
        weeklyGrid.setBackground(ThemeColors.BACKGROUND_LIGHT);
        weeklyGrid.setBorder(new EmptyBorder(10, 20, 10, 20));

        DateTimeFormatter headerFormat = DateTimeFormatter.ofPattern("dd MMM");
        DateTimeFormatter dayNameFormat = DateTimeFormatter.ofPattern("EEEE");
        DateTimeFormatter matchFormat = DateTimeFormatter.ofPattern("dd MMMM EEEE");

        LocalDateTime startDay = LocalDateTime.now();

        for (int i = 0; i < 7; i++) {
            LocalDateTime currentDay = startDay.plusDays(i);
            boolean isHalkGunu = currentDay.getDayOfWeek() == DayOfWeek.WEDNESDAY;
            Color columnBgColor = isHalkGunu ? new Color(255, 248, 240) : Color.WHITE;
            Color headerBgColor = isHalkGunu ? new Color(255, 230, 210) : new Color(245, 245, 245);

            JPanel dayColumn = new JPanel(new BorderLayout());
            dayColumn.setBackground(columnBgColor);
            dayColumn.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220), 1));

            String datePart = currentDay.format(headerFormat);
            String dayPart = currentDay.format(dayNameFormat);
            String htmlText = isHalkGunu ?
                    "<html><center>" + datePart + "<br>" + dayPart + "<br><font color='red' size='2'>(Halk Günü)</font></center></html>" :
                    "<html><center>" + datePart + "<br>" + dayPart + "<br><font size='2'>&nbsp;</font></center></html>";

            JLabel lblDate = new JLabel(htmlText, SwingConstants.CENTER);
            lblDate.setFont(new Font("SansSerif", Font.BOLD, 13));
            lblDate.setBorder(new EmptyBorder(10, 2, 10, 2));
            lblDate.setOpaque(true);
            lblDate.setBackground(headerBgColor);

            if (isHalkGunu) lblDate.setForeground(new Color(200, 50, 0));
            else lblDate.setForeground(ThemeColors.TEXT_DARK);

            dayColumn.add(lblDate, BorderLayout.NORTH);

            JPanel sessionsList = new JPanel();
            sessionsList.setLayout(new BoxLayout(sessionsList, BoxLayout.Y_AXIS));
            sessionsList.setBackground(columnBgColor);
            sessionsList.setBorder(new EmptyBorder(15, 5, 15, 5));

            String currentDayStr = currentDay.format(matchFormat);
            boolean sessionFound = false;

            for (Session s : m.getSessions()) {
                if (s.getDateTime().format(matchFormat).equals(currentDayStr)) {
                    sessionFound = true;
                    JButton sBtn = new JButton(s.getFormattedTime());
                    sBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
                    sBtn.setFont(new Font("SansSerif", Font.BOLD, 15));

                    if (isHalkGunu) {
                        sBtn.setBackground(new Color(255, 152, 0));
                        sBtn.setForeground(Color.WHITE);
                    } else {
                        sBtn.setBackground(ThemeColors.PRIMARY_ORANGE);
                        sBtn.setForeground(Color.WHITE);
                    }
                    sBtn.setMaximumSize(new Dimension(90, 35));
                    sBtn.setFocusPainted(false);

                    sBtn.addActionListener(e -> {
                        selectedSession = s;
                        mainPanel.add(createTicketQuantityPanel(), "QUANTITY");
                        cardLayout.show(mainPanel, "QUANTITY");
                    });

                    sessionsList.add(sBtn);
                    sessionsList.add(Box.createVerticalStrut(10));
                }
            }
            if (!sessionFound) {
                JLabel noSession = new JLabel("<html><center>Seans<br>Yok</center></html>");
                noSession.setAlignmentX(Component.CENTER_ALIGNMENT);
                noSession.setForeground(Color.GRAY);
                noSession.setFont(new Font("SansSerif", Font.ITALIC, 11));
                sessionsList.add(noSession);
            }
            dayColumn.add(sessionsList, BorderLayout.CENTER);
            weeklyGrid.add(dayColumn);
        }

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBackground(ThemeColors.BACKGROUND_LIGHT);
        JButton btnBack = new JButton("<< SİNEMA SEÇİMİNE DÖN");
        styleOrangeButton(btnBack);
        btnBack.setBackground(Color.GRAY);
        btnBack.addActionListener(e -> cardLayout.show(mainPanel, "CINEMA"));
        bottomPanel.add(btnBack);

        JScrollPane scrollPane = new JScrollPane(weeklyGrid);
        scrollPane.setBorder(null);
        scrollPane.getHorizontalScrollBar().setUnitIncrement(16);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        return panel;
    }

    // BİLET ADEDİ
    private JPanel createTicketQuantityPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);

        int availableSeats = selectedSession.getAvailableSeatCount();
        JLabel lblInfo = new JLabel("Bu seansta " + availableSeats + " adet boş koltuk var.");
        lblInfo.setForeground(Color.RED);

        boolean isHalkGunu = selectedSession.getDateTime().getDayOfWeek() == DayOfWeek.WEDNESDAY;
        double basePrice = isHalkGunu ? 100.0 : selectedMovie.getPrice();
        double studentPrice = basePrice * 0.8;

        countTam = 0; countOgrenci = 0; countAskida = 0; countBagis = 0;

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblTitle = new JLabel("Bilet Adedi Seçiniz");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 24));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(lblTitle, gbc);
        gbc.gridy = 1; panel.add(lblInfo, gbc);

        SpinnerNumberModel modelTam = new SpinnerNumberModel(0, 0, availableSeats, 1);
        JSpinner spinTam = new JSpinner(modelTam);

        SpinnerNumberModel modelOgr = new SpinnerNumberModel(0, 0, availableSeats, 1);
        JSpinner spinOgrenci = new JSpinner(modelOgr);

        gbc.gridwidth = 1; gbc.gridy = 2; gbc.gridx = 0; panel.add(new JLabel("Tam (" + basePrice + " TL):"), gbc);
        gbc.gridx = 1; panel.add(spinTam, gbc);

        if (!isHalkGunu) {
            gbc.gridy = 3; gbc.gridx = 0; panel.add(new JLabel("Öğrenci (" + studentPrice + " TL):"), gbc);
            gbc.gridx = 1; panel.add(spinOgrenci, gbc);
        } else {
            JLabel lblHalk = new JLabel("<html><i>Halk Günü: Öğrenci biletleri standart fiyattır.</i></html>");
            lblHalk.setForeground(new Color(200,0,0));
            gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2; panel.add(lblHalk, gbc);
            gbc.gridwidth = 1;
        }

        JSpinner spinAskida = new JSpinner(new SpinnerNumberModel(0, 0, suspendedTicketsPool, 1));
        gbc.gridy = 4; gbc.gridx = 0; panel.add(new JLabel("Askıda Kullan (Stok: " + suspendedTicketsPool + "):"), gbc);
        gbc.gridx = 1; panel.add(spinAskida, gbc);

        JSpinner spinBagis = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
        gbc.gridy = 5; gbc.gridx = 0; panel.add(new JLabel("<html><font color='green'>Askıda Bilet Bırak / Bağış Yap:</font></html>"), gbc);
        gbc.gridx = 1; panel.add(spinBagis, gbc);

        JLabel lblTotal = new JLabel("Toplam: 0.0 TL");
        lblTotal.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTotal.setForeground(ThemeColors.PRIMARY_ORANGE);
        gbc.gridy = 6; gbc.gridx = 0; gbc.gridwidth = 2;
        panel.add(lblTotal, gbc);

        javax.swing.event.ChangeListener updatePrice = e -> {
            int t = (int) spinTam.getValue();
            int o = isHalkGunu ? 0 : (int) spinOgrenci.getValue();
            int a = (int) spinAskida.getValue();
            int b = (int) spinBagis.getValue();
            int currentSeatCount = t + o + a;
            if (currentSeatCount > availableSeats) JOptionPane.showMessageDialog(panel, "Dikkat! Sadece " + availableSeats + " boş koltuk var.");
            double total = (t * basePrice) + (o * studentPrice) + (b * basePrice);
            lblTotal.setText("Toplam: " + total + " TL");
        };
        spinTam.addChangeListener(updatePrice);
        spinOgrenci.addChangeListener(updatePrice);
        spinAskida.addChangeListener(updatePrice);
        spinBagis.addChangeListener(updatePrice);

        JButton btnNext = new JButton("KOLTUK SEÇİMİNE GEÇ >>");
        styleOrangeButton(btnNext);
        gbc.gridy = 7;
        btnNext.addActionListener(e -> {
            countTam = (int) spinTam.getValue();
            countOgrenci = isHalkGunu ? 0 : (int) spinOgrenci.getValue();
            countAskida = (int) spinAskida.getValue();
            countBagis = (int) spinBagis.getValue();
            totalSeatsNeeded = countTam + countOgrenci + countAskida;
            currentTotalPrice = (countTam * basePrice) + (countOgrenci * studentPrice) + (countBagis * basePrice);

            if (totalSeatsNeeded > availableSeats) JOptionPane.showMessageDialog(panel, "Seçtiğiniz bilet sayısı boş koltuklardan fazla!");
            else if (totalSeatsNeeded == 0 && countBagis == 0) JOptionPane.showMessageDialog(panel, "Lütfen en az 1 işlem seçiniz.");
            else if (totalSeatsNeeded == 0 && countBagis > 0) showPaymentForm();
            else {
                selectedSeatsList.clear();
                mainPanel.add(createSeatPanel(selectedSession), "SEAT");
                cardLayout.show(mainPanel, "SEAT");
            }
        });
        panel.add(btnNext, gbc);

        JButton btnBack = new JButton("<< GERİ");
        btnBack.setBackground(Color.GRAY);
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(ev -> cardLayout.show(mainPanel, "SESSION"));
        gbc.gridy = 8;
        panel.add(btnBack, gbc);
        return panel;
    }

    // KOLTUK SEÇİMİ
    private JPanel createSeatPanel(Session session) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ThemeColors.BACKGROUND_LIGHT);

        JPanel infoPanel = new JPanel(new GridLayout(2, 1));
        infoPanel.setBackground(ThemeColors.BACKGROUND_LIGHT);
        JLabel lblInfo = new JLabel("Lütfen " + totalSeatsNeeded + " adet koltuk seçiniz.", SwingConstants.CENTER);
        lblInfo.setFont(new Font("SansSerif", Font.BOLD, 18));
        JLabel lblSelected = new JLabel("Seçilen: 0 / " + totalSeatsNeeded, SwingConstants.CENTER);
        lblSelected.setForeground(ThemeColors.PRIMARY_ORANGE);
        infoPanel.add(lblInfo);
        infoPanel.add(lblSelected);
        panel.add(infoPanel, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(12, 10, 5, 5));
        grid.setBackground(ThemeColors.BACKGROUND_LIGHT);
        grid.setBorder(new EmptyBorder(10, 100, 10, 100));

        JButton btnPay = new JButton("ÖDEMEYİ TAMAMLA (" + currentTotalPrice + " TL)");
        styleOrangeButton(btnPay);
        btnPay.setEnabled(false);

        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 10; j++) {
                Seat seatObj = session.getSeats()[i][j];
                JButton seatBtn = new JButton(seatObj.getId());
                seatBtn.setFont(new Font("Arial", Font.PLAIN, 9));
                if (seatObj.isOccupied()) {
                    seatBtn.setBackground(ThemeColors.SEAT_FULL);
                    seatBtn.setEnabled(false);
                } else {
                    seatBtn.setBackground(ThemeColors.SEAT_EMPTY);
                    seatBtn.setForeground(Color.WHITE);
                }
                seatBtn.addActionListener(e -> {
                    if (selectedSeatsList.contains(seatObj)) {
                        selectedSeatsList.remove(seatObj);
                        seatBtn.setBackground(ThemeColors.SEAT_EMPTY);
                    } else {
                        if (selectedSeatsList.size() < totalSeatsNeeded) {
                            selectedSeatsList.add(seatObj);
                            seatBtn.setBackground(ThemeColors.SEAT_SELECTED);
                        } else {
                            JOptionPane.showMessageDialog(panel, "Maksimum " + totalSeatsNeeded + " koltuk seçebilirsiniz.");
                        }
                    }
                    lblSelected.setText("Seçilen: " + selectedSeatsList.size() + " / " + totalSeatsNeeded);
                    btnPay.setEnabled(selectedSeatsList.size() == totalSeatsNeeded);
                });
                grid.add(seatBtn);
            }
        }
        btnPay.addActionListener(e -> {
            if (currentTotalPrice == 0) processBatchBooking(null);
            else showPaymentForm();
        });

        JButton btnBack = new JButton("<< BİLET ADEDİNE DÖN");
        styleOrangeButton(btnBack);
        btnBack.setBackground(Color.GRAY);
        btnBack.addActionListener(e -> cardLayout.show(mainPanel, "QUANTITY"));

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(btnPay, BorderLayout.CENTER);
        bottomPanel.add(btnBack, BorderLayout.SOUTH);
        panel.add(grid, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        return panel;
    }

    //ÖDEME EKRANI
    private void showPaymentForm() {
        JDialog payDialog = new JDialog(this, "Güvenli Ödeme", true);
        payDialog.setSize(400, 480);
        payDialog.setLayout(new GridLayout(7, 1, 10, 10));
        payDialog.setLocationRelativeTo(this);

        JLabel lblTitle = new JLabel("Ödenecek Tutar: " + currentTotalPrice + " TL");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);

        JTextField txtCardNo = new JTextField();
        txtCardNo.setBorder(BorderFactory.createTitledBorder("Kart Numarası (16 Hane)"));
        txtCardNo.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar()) && e.getKeyChar() != KeyEvent.VK_SPACE) e.consume();
                if (txtCardNo.getText().length() >= 19) e.consume();
            }
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() != KeyEvent.VK_BACK_SPACE) {
                    String text = txtCardNo.getText().replace(" ", "");
                    StringBuilder formatted = new StringBuilder();
                    for(int i = 0; i < text.length(); i++) {
                        if (i > 0 && i % 4 == 0) formatted.append(" ");
                        formatted.append(text.charAt(i));
                    }
                    txtCardNo.setText(formatted.toString());
                }
            }
        });

        JTextField txtCardName = new JTextField();
        txtCardName.setBorder(BorderFactory.createTitledBorder("Kart Üzerindeki İsim"));
        JPanel cvcPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        JTextField txtExp = new JTextField();
        txtExp.setBorder(BorderFactory.createTitledBorder("Son K.T (AA/YY)"));
        txtExp.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) e.consume();
                if (txtExp.getText().length() >= 5) e.consume();
            }
            public void keyReleased(KeyEvent e) {
                if (txtExp.getText().length() == 2 && e.getKeyCode() != KeyEvent.VK_BACK_SPACE) txtExp.setText(txtExp.getText() + "/");
            }
        });
        JTextField txtCvc = new JTextField();
        txtCvc.setBorder(BorderFactory.createTitledBorder("CVV (3 Hane)"));
        txtCvc.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {

                if (!Character.isDigit(e.getKeyChar()) || txtCvc.getText().length() >= 3) e.consume();
            }
        });
        cvcPanel.add(txtExp);
        cvcPanel.add(txtCvc);

        JButton btnFinalize = new JButton("ÖDEMEYİ ONAYLA");
        styleOrangeButton(btnFinalize);
        btnFinalize.setBackground(new Color(46, 125, 50));
        btnFinalize.addActionListener(e -> {
            String rawCard = txtCardNo.getText().replace(" ", "");
            if (rawCard.length() != 16) {
                //kart numarası 16 haneden eksikse hata verir
                JOptionPane.showMessageDialog(payDialog, "Kart numarası eksik!", "Hata", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (txtExp.getText().length() != 5) {
                // son kullanma tarihi / ile birlikte 5 karakterden eksikse hata verir
                JOptionPane.showMessageDialog(payDialog, "Tarih hatalı!", "Hata", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (txtCvc.getText().length() != 3) {
                //cvvnin 3 karakterden az girilmesini engeller
                JOptionPane.showMessageDialog(payDialog, "CVV hatalı!", "Hata", JOptionPane.WARNING_MESSAGE);
                return;
            }
            processBatchBooking(payDialog);
        });

        payDialog.add(lblTitle);
        payDialog.add(txtCardName);
        payDialog.add(txtCardNo);
        payDialog.add(cvcPanel);
        payDialog.add(new JLabel(" "));
        payDialog.add(btnFinalize);
        payDialog.setVisible(true);
    }

    private void processBatchBooking(Dialog parentDialog) {
        try {
            // Stok ve Bağış Kontrolü
            if (countAskida > 0) {
                if (suspendedTicketsPool >= countAskida) suspendedTicketsPool -= countAskida;
                else throw new BusinessException("Askıda bilet stoğu yetersiz!");
            }
            if (countBagis > 0) suspendedTicketsPool += countBagis;


            /*Sadece bağış yapılıyorsa
             sistemin koltuk listesine bakmasını ZORLA ENGELLİYORUZ */

            if (totalSeatsNeeded == 0) {
                selectedSeatsList.clear(); // Listeyi zorla boşalt
            }


            // Koltuk İşlemleri
            StringBuilder seatsStr = new StringBuilder();
            if (!selectedSeatsList.isEmpty()) {
                for (Seat s : selectedSeatsList) {
                    // Sadece listede koltuk varsa doluluk kontrolü yap
                    if (s.isOccupied()) throw new SeatOccupiedException(s.getId());
                    s.setOccupied(true);
                    seatsStr.append(s.getId()).append(" ");
                }
            } else {
                seatsStr.append("(Sadece Bağış)");
            }

            // Bilet Bilgisini Oluştur
            String fullLocationInfo = selectedCinema + " - " + selectedSession.getFormattedTime();
            String ticketInfo = selectedMovie.getName() + " | " + fullLocationInfo + " | Koltuklar: " + seatsStr;

            //  Hafızaya Ekle
            currentUser.addTicketToHistory(ticketInfo);

            //DOSYAYA KAYDET
            FileHelper.saveTicketToFile(currentUser.getUsername(), ticketInfo);

            //  Mail Gönder
            new Thread(() -> {
                try {
                    EmailService.sendTicketEmail(
                            currentUser.getEmail(),
                            currentUser.getAppPassword(),
                            currentUser.getEmail(),
                            selectedMovie.getName(),
                            selectedSession.getFullDateInfo() + "\nLokasyon: " + selectedCinema,
                            seatsStr.toString(),
                            currentTotalPrice
                    );
                } catch (Exception e) {
                    SwingUtilities.invokeLater(() ->
                            JOptionPane.showMessageDialog(null, "Mail gönderilemedi! Uygulama şifrenizi kontrol ediniz.")
                    );
                }
            }).start();

            // Loglama ve UI Güncelleme
            FileHelper.logIslem("SATIŞ: " + currentUser.getUsername() + " | " + ticketInfo);
            JOptionPane.showMessageDialog(this, "İşlem Başarılı! Bilet mail adresinize gönderiliyor...", "Başarılı", JOptionPane.INFORMATION_MESSAGE);

            if (parentDialog != null) parentDialog.dispose();
            cardLayout.show(mainPanel, "HOME");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }
    //YAPAY ZEKA ÖNERİ SİSTEMİ
    private void startSmartSuggestionLoop() {
        String[] moods = {"😔 Üzgünüm", "😤 Gerginim", "🤔 Meraklıyım", "💘 Romantiğim"};
        String selectedMood = (String) JOptionPane.showInputDialog(this, "Modun ne?", "AI", JOptionPane.QUESTION_MESSAGE, null, moods, moods[0]);
        if (selectedMood == null) return;
        String genre = selectedMood.contains("Üzgünüm") ? "Komedi" : selectedMood.contains("Gerginim") ? "Aksiyon" : selectedMood.contains("Meraklıyım") ? "Bilim" : "Dram";
        suggestMovieRecursive(genre, new ArrayList<>());
    }
    private void suggestMovieRecursive(String genre, List<String> rejectedGenres) {
        Movie suggestion = movieService.getAll().stream().filter(m -> m.getGenre().contains(genre)).findFirst().orElse(null);
        if (suggestion != null) {
            Object[] options = {"Evet, İsterim", "Hayır"};
            int choice = JOptionPane.showOptionDialog(this, "Öneri: " + suggestion.getName() + "\nİster misin?", "AI", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (choice == 0) {
                selectedMovie = suggestion;
                mainPanel.add(createCinemaSelectionPanel(suggestion), "CINEMA");
                cardLayout.show(mainPanel, "CINEMA");
            } else if (choice == 1) {
                rejectedGenres.add(genre);
                String next = findNextGenre(rejectedGenres);
                if (next != null) suggestMovieRecursive(next, rejectedGenres);
                else JOptionPane.showMessageDialog(this, "Başka tür kalmadı.");
            }
        } else JOptionPane.showMessageDialog(this, "Bu türde film yok.");
    }
    private String findNextGenre(List<String> rejected) {
        String[] all = {"Aksiyon", "Komedi", "Bilim", "Dram"};
        for(String g : all) {
            boolean isRej = false;
            for(String r : rejected) if(r.contains(g)) isRej = true;
            if(!isRej) return g;
        }
        return null;
    }

    private void styleOrangeButton(JButton btn) {
        btn.setBackground(ThemeColors.PRIMARY_ORANGE);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setBorderPainted(false);
        btn.setOpaque(true);
    }
}