package com.cineverse.main;

import com.cineverse.gui.MainFrame;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // GUI'yi Event Dispatch Thread üzerinde başlatma
        SwingUtilities.invokeLater(() -> {
            try {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            } catch (Exception e) {
                // Try-catch kullanımı
                e.printStackTrace();
            } finally {
                // Finally bloğu
                System.out.println("Uygulama yükleme süreci tamamlandı.");
            }
        });
    }
}