package com.cineverse.model;

// Soyut Sınıf
public abstract class BaseEntity {
    // Değişkenler private yapılarak dışarıdan doğrudan müdahale engellenir.
    private int id;
    private String name;

    // Constructor Overloading  eğer ID ve İsim belliyse bu yapıcı kullanılır.
    public BaseEntity(int id, String name) {
        this.id = id;
        this.name = name;
    }
//Eğer sadece İsim biliniyorsa bu yapıcı kullanılır.
    public BaseEntity(String name) {
        // Math.random() 0.0 ile 1.0 arasında sayı üretir.
        // Bunu 1000 ile çarpıp int'e çevirerek basit bir ID üretiyoruz.
        this.id = (int)(Math.random() * 1000);
        this.name = name;
    }

    // Soyut Metotlar
    public abstract String getDetails();
    public abstract void updateStatus(boolean isActive);

    // Somut Metotlar
    public int getId() { return id; }
    public String getName() { return name; }
}