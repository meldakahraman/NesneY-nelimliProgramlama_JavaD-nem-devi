package com.cineverse.model;

import java.util.ArrayList;
import java.util.List;
//Discountable arayüzünü uygular (İndirim hesaplama yeteneği kazanır)
public class Customer extends User implements Discountable {
    private boolean isStudent;//Öğrenci mi
    private String email;
    private String appPassword;
    private List<String> ticketHistory;// Satın alınan biletlerin listesi


    public Customer(String name, String username, String password, String appPassword, String email, byte age, boolean isStudent) {
        super(name, username, password, age); // User sınıfına her ikisini de gönderiyoruz
        this.appPassword = appPassword;
        this.email = email;
        this.isStudent = isStudent;
        this.ticketHistory = new ArrayList<>();
    }
    //               Getter Metotları
    public String getEmail() { return email; }
    public String getAppPassword() { return appPassword; }

    //             Bilet Geçmişi Yönetimi
    public void addTicketToHistory(String ticketInfo) {
        ticketHistory.add(ticketInfo);
    }

    public List<String> getTicketHistory() { return ticketHistory; }
    //üst sınıflardan gelen metodlar
    @Override
    public String getRole() { return "MUSTERI"; }
    @Override
    public boolean canLogin() { return isActive; }
    @Override
    public double calculateDiscount(double price) { return isStudent ? price * 0.80 : price; }
    @Override
    public boolean isEligibleForDiscount() { return isStudent; }
    @Override
    public String getDiscountName() { return isStudent ? "Öğrenci İndirimi" : "Standart"; }
}