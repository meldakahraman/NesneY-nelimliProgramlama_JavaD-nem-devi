package com.cineverse.model;
//indirim yapan arayüz
public interface Discountable {
   // Nesnenin indirime uygun olup olmadığını kontrol eder.
    double calculateDiscount(double price);

    //Ekranda veya fişte gösterilecek indirim adını döndürür öğrenci indirimi vs.
    boolean isEligibleForDiscount();
    String getDiscountName();
}