package com.cineverse.model;

import com.cineverse.exception.BusinessException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Movie extends BaseEntity implements Sellable {
    private double price; // Bilet tam fiyatı
    private String genre; // Film türü
    private int durationMinutes; // Film süresi
    private List<Session> sessions; // Filme ait seansların listesi

    public Movie(int id, String name, double price, String genre, int duration) {
        super(id, name);
        this.price = price;
        this.genre = genre;
        this.durationMinutes = duration;
        this.sessions = new ArrayList<>();
        // Film oluşturulur oluşturulmaz, otomatik olarak 1 haftalık programı hazırla
        generateWeeklySessions();
    }

    //       7 GÜNLÜK SEANS OLUŞTURMA
    private void generateWeeklySessions() {
        // Başlangıç noktası: Bugünün tarihi, Saat 10:00
        LocalDateTime startDay = LocalDateTime.now().withHour(10).withMinute(0);

        // dış döngü 7 gün
        for (int day = 0; day < 7; day++) {
            LocalDateTime currentDay = startDay.plusDays(day);

            // Günde 4 seans (10:00, 13:00, 16:00, 19:00)
            for(int i = 0; i < 4; i++) {
                sessions.add(new Session(currentDay.plusHours(i * 3)));
            }
        }
    }

    public List<Session> getSessions() { return sessions; }

    @Override
    public String getDetails() { return getName() + " (" + genre + ") - " + durationMinutes + " dk"; }

    @Override
    public void updateStatus(boolean isActive) {}

    public void setDurationMinutes(int durationMinutes) throws BusinessException {
        //Film süresi 0 veya negatif olamaz.
        if (durationMinutes <= 0) throw new BusinessException("Süre hatası");
        this.durationMinutes = durationMinutes;
    }

    @Override
    public double getPrice() { return price; }
    @Override
    public void setPrice(double price) { this.price = price; }
    @Override
    public String getDescription() { return getDetails(); }
    public String getGenre() { return genre; }
}