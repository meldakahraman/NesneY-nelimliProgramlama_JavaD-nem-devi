package com.cineverse.model;
    // koltuk sınıfı
public class Seat {
    private String row; //sıra harfi
    private int number; //koltuk numarası
    // koltuk dolu mu
    private boolean isOccupied;
    // kullanıcı koltuğu seçti mi
    private boolean isSelected;

    public Seat(String row, int number, boolean isOccupied) {
        this.row = row;
        this.number = number;
        this.isOccupied = isOccupied;
        //kullanıcı tıklayana kadar seçili değildir
        this.isSelected = false;
    }

    public String getId() { return row + number; }
    public boolean isOccupied() { return isOccupied; }
    public void setOccupied(boolean occupied) { isOccupied = occupied; }
    public boolean isSelected() { return isSelected; }
    public void setSelected(boolean selected) { isSelected = selected; }
}