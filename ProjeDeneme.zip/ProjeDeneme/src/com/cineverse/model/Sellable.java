package com.cineverse.model;
//satılabilen her ürün için uygulanacak arayüz
public interface Sellable {
    double getPrice(); // satış fiyatı
    void setPrice(double price); // Fiyat güncelleme

    //Ürünün kullanıcıya gösterilecek kısa tanımıdır (Avatar 2 Bileti vs.)
    String getDescription();
}