package com.cineverse.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Session {
    private LocalDateTime time;
    //Salonun koltuk planı (12 satır x 10 sütunluk matris)
    private Seat[][] seats;

    public Session(LocalDateTime time) {
        this.time = time;
        // Seans oluşturulduğu an koltukları da hazırlar ve rastgele doldurur.
        initializeSeats();
    }

    private void initializeSeats() {
        seats = new Seat[12][10];
        char rowChar = 'A';

        for (int i = 0; i < 12; i++) {// Satırları gezer
            for (int j = 0; j < 10; j++) {// Sütunları gezer
                // Rastgele doluluk simülasyonu %30 doluluk oranı ile
                boolean isRandomFull = Math.random() < 0.3;
                seats[i][j] = new Seat(String.valueOf(rowChar), j + 1, isRandomFull);
            }
            rowChar++;
        }
    }

    public Seat[][] getSeats() { return seats; }

    public String getFormattedTime() {
        return time.format(DateTimeFormatter.ofPattern("HH:mm"));
    }

    public String getFullDateInfo() {
        return time.format(DateTimeFormatter.ofPattern("dd MMMM yyyy - HH:mm"));
    }

    public LocalDateTime getDateTime() {
        return time;
    }


    // Seanstaki boş koltuk sayısını hesaplar
    public int getAvailableSeatCount() {
        int count = 0;

        // Dış döngü: Satırları gezer
        for (int i = 0; i < seats.length; i++) {
            // İç döngü: o satırdaki koltukları gezer
            for (int j = 0; j < seats[0].length; j++) {
                if (!seats[i][j].isOccupied()) {
                    count++;
                }
            }
        }
        return count;
    }
}