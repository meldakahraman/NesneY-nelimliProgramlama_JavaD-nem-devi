package com.cineverse.model;

public abstract class User {
    protected String name; // Ad Soyad (Real Name)
    protected String username; // Kullanıcı Adı (Nick)
    protected String password;
    // Bellek tasarrufu için 'int' yerine 'byte' tercih edildi.
    protected byte age;
    // Kullanıcı hesabı dondurulmuş mu yoksa aktif mi?
    protected boolean isActive;

    // Yeni bir kullanıcı oluşturulurken çalışır.
    public User(String name, String username, String password, byte age) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.age = age;
        // Yeni oluşturulan her kullanıcı varsayılan olarak aktiftir.
        this.isActive = true;
    }

    public abstract String getRole();
    public abstract boolean canLogin();

    //Getter Metotları
    public String getName() { return name; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
}