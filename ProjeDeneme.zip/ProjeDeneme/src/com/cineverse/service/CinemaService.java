package com.cineverse.service;

import com.cineverse.model.*;
import java.util.*;

// Generic Sınıf Tanımı
public class CinemaService<T extends BaseEntity> {

    // Verileri sıralı bir liste olarak tutar
    private List<T> items = new ArrayList<>();
    // Verileri "Anahtar-Değer" ikilisi olarak tutar
    private Map<String, T> itemMap = new HashMap<>();

    // Koleksiyon ekleme
    public void add(T item) {
        items.add(item);
        // İsmi anahtar (key) olarak kullanarak Map'e ekle
        itemMap.put(item.getName(), item);
    }

    // Koleksiyon silme
    public void remove(T item) {
        items.remove(item); // Listeden sil
        itemMap.remove(item.getName()); // Map'ten isme göre sil
    }

    public List<T> getAll() {
        return items;
    }

    // Generic Metot
    public <E> void printArray(E[] inputArray) {
        for (E element : inputArray) {
            System.out.printf("%s ", element);
        }
        System.out.println();
    }

    // Wildcard kullanımı
    public double sumPrices(List<? extends Number> prices) {
        double sum = 0.0;
        for (Number n : prices) {
            sum += n.doubleValue();// Gelen sayı ne olursa olsun double'a çevirip toplar
        }
        return sum;
    }
}