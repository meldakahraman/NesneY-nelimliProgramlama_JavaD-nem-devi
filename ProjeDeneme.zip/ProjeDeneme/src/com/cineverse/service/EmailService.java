package com.cineverse.service;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailService {

    // Bilet Gönderme
    public static void sendTicketEmail(String senderEmail, String senderPassword, String toEmail,
                                       String movieName, String sessionInfo, String seats, double amount) {
        sendEmailBase(senderEmail, senderPassword, toEmail, "MEGEVERSE Biletiniz Hazır! 🎬",
                "Sayın Kullanıcımız,\n\n"
                        + "Satın alma işleminiz başarıyla gerçekleşti.\n"
                        + "------------------------------------------------\n"
                        + "Film: " + movieName + "\n"
                        + "Seans: " + sessionInfo + "\n"
                        + "Koltuklar: " + seats + "\n"
                        + "Toplam Tutar: " + amount + " TL\n"
                        + "------------------------------------------------\n\n"
                        + "İyi seyirler dileriz!\n"
                        + "- MEGEVERSE Ekibi");
    }

    // şifre hatırlatma sadece kayıtlı mail adresine gönderilir
    public static void sendRecoveryEmail(String senderEmail, String senderPassword, String toEmail, String recoveredPass) {
        sendEmailBase(senderEmail, senderPassword, toEmail, "MEGEVERSE Şifre Hatırlatma 🔑",
                "Merhaba,\n\n"
                        + "Şifrenizi unuttuğunuzu belirttiniz.\n"
                        + "------------------------------------------------\n"
                        + "Sistem Giriş Şifreniz: " + recoveredPass + "\n"
                        + "------------------------------------------------\n\n"
                        + "Lütfen bu şifreyi kimseyle paylaşmayınız.\n"
                        + "İyi günler dileriz.\n"
                        + "- MEGEVERSE Güvenlik Ekibi");
    }

    // Ortak Gönderme Metodu
    private static void sendEmailBase(String senderEmail, String senderPassword, String toEmail, String subject, String body) {
        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com"); // Gmail sunucusu
        prop.put("mail.smtp.port", "587"); // TLS Portu
        prop.put("mail.smtp.auth", "true"); // Giriş yapmak zorunlu
        prop.put("mail.smtp.starttls.enable", "true");
    // kimlik doğrulama
        Session session = Session.getInstance(prop, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            //Mesajı Oluşturma
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            // Kime
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);// Konu Başlığı
            message.setText(body);// Mesaj İçeriği
            Transport.send(message);
            System.out.println("Mail gönderildi: " + subject);
        } catch (MessagingException e) {
            e.printStackTrace();
            throw new RuntimeException("Mail gönderilemedi: " + e.getMessage());
        }
    }
}