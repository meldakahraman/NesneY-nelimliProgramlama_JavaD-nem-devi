package com.cineverse.util;

import com.cineverse.model.Customer;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileHelper {
    public static final String LOG_FILE = "system_logs.txt";
    public static final String USERS_FILE = "users.txt";
    public static final String TICKETS_FILE = "tickets.txt"; // YENİ: Bilet Dosyası

    // Loglama
    public static void logIslem(String mesaj) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            writer.write(LocalDateTime.now() + " - " + mesaj + "\n");
        } catch (IOException e) {
            System.err.println("Loglama hatası: " + e.getMessage());
        }
    }

    // Kullanıcı Kaydetme
    public static void saveUserToFile(Customer user) {
        String line = user.getUsername() + "###" +
                user.getName() + "###" +
                user.getPassword() + "###" +
                user.getAppPassword() + "###" +
                user.getEmail();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE, true))) {
            writer.write(line + "\n");
        } catch (IOException e) {
            System.err.println("Kullanıcı kaydetme hatası: " + e.getMessage());
        }
    }

    // Kullanıcıları Yükleme
    public static Map<String, Customer> loadUsersFromFile() {
        Map<String, Customer> users = new HashMap<>();
        File file = new File(USERS_FILE);
        if (!file.exists()) return users;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("###");
                if (parts.length >= 5) {
                    String uName = parts[0];
                    String name = parts[1];
                    String pass = parts[2];
                    String appPass = parts[3];
                    String email = parts[4];
                    Customer c = new Customer(name, uName, pass, appPass, email, (byte)20, true);
                    users.put(uName, c);
                }
            }
        } catch (IOException e) {
            System.err.println("Kullanıcı yükleme hatası: " + e.getMessage());
        }
        return users;
    }

    //  BİLETİ DOSYAYA KAYDETME
    public static void saveTicketToFile(String username, String ticketInfo) {
        // Format: KullanıcıAdı###BiletDetayı
        String line = username + "###" + ticketInfo;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TICKETS_FILE, true))) {
            writer.write(line + "\n");
        } catch (IOException e) {
            System.err.println("Bilet kaydetme hatası: " + e.getMessage());
        }
    }

    //  KULLANICININ ESKİ BİLETLERİNİ YÜKLEME
    public static List<String> loadTicketsForUser(String username) {
        List<String> tickets = new ArrayList<>();
        File file = new File(TICKETS_FILE);
        if (!file.exists()) return tickets;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("###");
                // Eğer satır bu kullanıcıya aitse listeye ekle
                if (parts.length >= 2 && parts[0].equals(username)) {
                    tickets.add(parts[1]); // Sadece bilet detayını al
                }
            }
        } catch (IOException e) {
            System.err.println("Bilet yükleme hatası: " + e.getMessage());
        }
        return tickets;
    }
}