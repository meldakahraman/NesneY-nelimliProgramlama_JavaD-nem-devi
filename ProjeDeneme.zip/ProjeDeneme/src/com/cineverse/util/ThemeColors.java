package com.cineverse.util;

import java.awt.Color;

public class ThemeColors {
    // Paribu Cineverse Tarzı Renk Paleti
    public static final Color PRIMARY_ORANGE = new Color(243, 112, 33); // Turuncu
    public static final Color BACKGROUND_LIGHT = new Color(248, 248, 248); // Kırık Beyaz
    public static final Color CARD_BG = Color.WHITE;
    public static final Color TEXT_DARK = new Color(33, 33, 33); // Koyu Gri
    public static final Color TEXT_LIGHT = new Color(150, 150, 150);
    public static final Color SEAT_EMPTY = new Color(139, 195, 74); // Yeşilimsi (boş)
    public static final Color SEAT_FULL = new Color(224, 224, 224); // Gri (Dolu)
    public static final Color SEAT_SELECTED = PRIMARY_ORANGE;
}